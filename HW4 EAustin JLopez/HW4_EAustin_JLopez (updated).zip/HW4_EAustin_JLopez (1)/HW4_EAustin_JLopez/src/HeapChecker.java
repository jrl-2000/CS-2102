public class HeapChecker {
    //our code goes here
    public HeapChecker(){

    }

    /**
     * adds an element to a heap and check to see if the new heap is valid
     * @param hOrig test heap
     * @param elt the element you want to add
     * @param hAdded the tree to pass in
     * @return
     */
    boolean addEltTester(IHeap hOrig, int elt, IBinTree hAdded) {
        if (hAdded.size() == -1){
            return false;
        } else {
            //Sees if they're heaps
            if(testHeap(hOrig) && testHeap(hAdded)){
                //Was the new element added
                if (hAdded.hasElt(elt)){
                    //Does it still have all the previous elements
                    if (hOrig.hasRestElt(hAdded)){
                        //Sees if element was added and nothing was removed
                        if(hAdded.size() == hOrig.size() +1){
                            return true;
                        }
                    }
                    }
                }
            }
        return false;
    }



    /**
     * removes the smallest element in a heap and tests to see if the heap
     * @param hOrig a test heap
     * @param hRemoved the tree to remove the element
     * @return
     */

    boolean remMinEltTester(IHeap hOrig, IBinTree hRemoved) {

    //...code to compare hOrig and hRemoved as appropriate...
        return  true; //plz change me

    }

    //Added

    //attempt 1 take in a BTree
    /**
     * tests to see if a Binary Tree is considered a heap
     * @param aTree a tree to be tested
     * @return a boolean whether it's a heap (true) or not a heap (false)
     */
    boolean testHeap(IBinTree aTree) {
        //if both are empty
        if (aTree.getRight().getData() == -1 && aTree.getLeft().getData() == -1) {
            return true;
        }
        //if the left side is empty recursively go down the right node
        if (aTree.getLeft().getData() == -1) {
            return aTree.getData() <= aTree.getLeft().getData() && testHeap(aTree.getRight());
        }
        // if the right side is empty recursively go down the left node
        if (aTree.getRight().getData() == -1) {
            return aTree.getData() <= aTree.getRight().getData() && testHeap(aTree.getLeft());
        } else {
            // check to see if the root is less than the right and left sides of the node and recursively goes down the tree
            if  (aTree.getData() <= aTree.getLeft().getData() && aTree.getData() <= aTree.getLeft().getData() && testHeap(aTree.getLeft()) && testHeap(aTree.getRight())){
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     *
     * @return
     */
    boolean hasRestElt(IBinTree first, IBinTree second) {
        //if the
        if (second.getRight() == new MtBT() && second.getLeft() == new MtBT()) {
            return true;
        } else {
            //check if the second tree has elements from the first tree and that the right side of the first tree is a BT
            if (second.hasElt(first.getData()) && first.getRight() == new MtBT()) {
                return first.getLeft().hasRestElt(second);
            } else {
                //Check left side
                if (first.getLeft() == new MtBT()) {
                    return first.getRight().hasRestElt(second);
                } else {
                    return first.getLeft().hasRestElt(second) && first.getRight().hasRestElt(second);
                }

            }
        }
    }

}



















