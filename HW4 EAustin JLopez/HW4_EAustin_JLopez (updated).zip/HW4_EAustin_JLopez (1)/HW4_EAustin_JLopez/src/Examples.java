import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Examples {

    Examples(){}
    //I'm not sure if we're supposed to reference the testheaps at all?
    HeapChecker HT = new HeapChecker();
    DataHeap heapA = new DataHeap(1);
    DataHeap heapB = new DataHeap(2);
    DataHeap heapC = new DataHeap(3);
    DataHeap noHeap = new DataHeap(3,heapB,heapA);



    //addEltTester test cases:

    @Test
    public void test1(){
        //assertTrue(HT.addEltTester(myHeap, 5, myBinTree));
    }
    @Test
    public void test2(){
        //assert____(HT.addEltTester(myHeap, 5, myBinTree));
    }
    @Test
    public void test3(){
        //assert____(HT.addEltTester(myHeap, 5, myBinTree));
    }
    @Test
    public void test4(){
        //assert____(HT.addEltTester(myHeap, 5, myBinTree));
    }
    @Test
    public void test5(){
        //assert____(HT.addEltTester(myHeap, 5, myBinTree));
    }
    @Test
    public void test6(){
        //assert____(HT.addEltTester(myHeap, 5, myBinTree));
    }

//remMinEltTester test cases:

    @Test
    public void atest1(){
        //assertTrue(HT.remMinEltTester(myHeap,myBinTree));
    }
    @Test
    public void atest2(){
        //assert____(HT.remMinEltTester(myHeap,myBinTree));
    }
    @Test
    public void atest3(){
        //assert____(HT.remMinEltTester(myHeap,myBinTree));
    }
    @Test
    public void atest4(){
        //assert____(HT.remMinEltTester(myHeap,myBinTree));
    }
    @Test
    public void atest5(){
        //assert____(HT.remMinEltTester(myHeap,myBinTree));
    }
    @Test
    public void atest6(){
        //assert____(HT.remMinEltTester(myHeap,myBinTree));
    }
}
