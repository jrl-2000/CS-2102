import org.junit.*;
import static org.junit.Assert.*;

public class ShootingRound {
    int targetsHit;



    public ShootingRound(int targetsHit) {

        this.targetsHit = targetsHit;
    }




}