// Homework 1
// Team 1266
// Emily Austin, Jonathan Lopez
// start date: 10/23/2020

package com.company;

class Main {

    public static void main(String[] args) {


    }
}