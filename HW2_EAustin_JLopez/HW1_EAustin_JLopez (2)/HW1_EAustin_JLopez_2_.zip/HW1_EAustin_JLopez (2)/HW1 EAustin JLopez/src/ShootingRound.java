import org.junit.*;
import static org.junit.Assert.*;

public class ShootingRound  {
    int targetsHit;
    boolean isStanding;



    public ShootingRound(int targetsHit, boolean isStanding) {

        this.targetsHit = targetsHit;
        this.isStanding = isStanding;
    }




}