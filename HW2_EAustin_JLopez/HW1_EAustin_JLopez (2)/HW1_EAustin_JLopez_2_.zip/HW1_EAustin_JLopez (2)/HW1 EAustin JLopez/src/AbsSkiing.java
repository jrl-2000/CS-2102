abstract class AbsSkiing implements IEvent {
    int penalties;
    int position;

    AbsSkiing (int penalties, int position) {
        this.penalties = penalties;
        this.position = position;

    }

}
