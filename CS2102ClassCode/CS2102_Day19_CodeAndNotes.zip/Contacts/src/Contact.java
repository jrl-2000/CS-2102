
public class Contact {

	String name;
	PhoneNumber phone;
	String email;
	Address thisAddress;
}

class PhoneNumber {
	String areaCode;
	String number;
}


class Address {
	int num;
	String street;
	int zipcode;

	//Overriding hashCode() method in Object
	public int hashCode() {
		return 3 * num + 17 * street.hashCode() + 23 * zipcode;
	}

	//Overriding equals method in Object
	public boolean equals(Object o) {
		Address addr = (Address) o;

		if(this.num == addr.num &&
			this.street.equals(addr.street) &&
			this.zipcode == addr.zipcode)
			return true;
		else
			return false;
	}

}