
public class Boa {

	String name;
	int length;
	String eats;
	
	public Boa(String name, int length, String eats) {
		this.name = name;
		this.length = length;
		this.eats = eats;
	}
	
	public boolean likesSameFood(Boa otherBoa) {
		return this.eats.equals(otherBoa.eats);
	}
	
	public boolean isShorterLength(Boa otherBoa) {
		return this.length < otherBoa.length;
	}
	
}
