public class AcctBinaryTree implements IAcctDataStructure {

    //private binary tree of accounts

    public Account findByNumber(int forAcctNum) {
        //traverse a tree to find the account
        return null;
    }
}
