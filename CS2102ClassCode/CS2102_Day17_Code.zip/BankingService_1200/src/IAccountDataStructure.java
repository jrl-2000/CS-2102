public interface IAccountDataStructure {

    public Account findByNumber( int acctNum) throws NullPointerException;
}
