public class AcctBinaryTree implements IAccountDataStructure {

    //binary tree of accounts

    public Account findByNumber( int acctNum) {
        //traverses the binary tree to find our account
        return null;
    }
}
