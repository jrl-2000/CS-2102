class TurboLift {
	private String liftNum;
	private String beginPoint;
	private String endPoint;
	
	public TurboLift(String liftNum, 
			String beginPoint, String endPoint) {
		this.liftNum = liftNum;
		this.beginPoint = beginPoint;
		this.endPoint = endPoint;
	}
}

class EngineRoom {

	private double currentWarp;

	public EngineRoom(double currentWarp) {
		this.currentWarp = currentWarp;
	}
	
	public void setWarp(double warp) {
		this.currentWarp = warp;
	}
}