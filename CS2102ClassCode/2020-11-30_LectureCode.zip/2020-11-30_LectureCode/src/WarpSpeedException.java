
public class WarpSpeedException extends Exception {
	
	private double warp;
	
	public WarpSpeedException(double warp) {
		this.warp = warp;
	}
	
	public double getWarp() {
		return warp;
	}

}
