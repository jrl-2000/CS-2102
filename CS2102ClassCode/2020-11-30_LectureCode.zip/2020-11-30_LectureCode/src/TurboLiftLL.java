import java.util.LinkedList;

public class TurboLiftLL implements ITurboLift {

	private LinkedList<TurboLift> turboLifts;
	
	public void addLift(TurboLift lift) {
		this.turboLifts.add(lift);
		
	}
	
}
