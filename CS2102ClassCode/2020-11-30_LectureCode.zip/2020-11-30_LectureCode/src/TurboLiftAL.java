import java.util.ArrayList;

public class TurboLiftAL implements ITurboLift {
	
	private ArrayList<TurboLift> turboLifts;
	
	public void addLift(TurboLift lift) {
		this.turboLifts.add(lift);
	}

}
