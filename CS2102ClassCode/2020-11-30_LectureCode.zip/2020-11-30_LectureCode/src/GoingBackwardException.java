
public class GoingBackwardException extends Exception {

}
