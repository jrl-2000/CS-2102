import java.util.LinkedList;

class Enterprise {

	private String shipNumber;
	private String captain;
	private EngineRoom er;
	private ITurboLift turboLifts;

	public Enterprise(String shipNumber, String captain, 
			EngineRoom er, ITurboLift turboLifts) {
		this.shipNumber = shipNumber;
		this.captain = captain;
		this.er = er;
		this.turboLifts = turboLifts;
	}
	
	public void changeWarpSpeed(double warp) throws GoingBackwardException {
		try {
			this.makeItSo(warp);
		}
		catch (WarpSpeedException e) {
			System.out.println("Warp " + e.getWarp() + " is beyond the theoretical limit");
		}

	}

	public String makeItSo(double warp) throws WarpSpeedException, GoingBackwardException {
		if(warp >= 10.0) {
			throw new WarpSpeedException(warp);
		}
		if (warp < 0.0) {
			throw new GoingBackwardException();
		}
		
		String s = "Ensign, go to warp " + warp;
		this.er.setWarp(warp);
		return s;
	}
	
	public void checkForWarpExceptions(double warp) throws Exception {
		
	}
	
	
	public void addLift(TurboLift lift) {
		this.turboLifts.addLift(lift);
	}
}


