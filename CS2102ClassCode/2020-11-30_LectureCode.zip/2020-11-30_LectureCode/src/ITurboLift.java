
public interface ITurboLift {
	
	public void addLift(TurboLift lift);

}
