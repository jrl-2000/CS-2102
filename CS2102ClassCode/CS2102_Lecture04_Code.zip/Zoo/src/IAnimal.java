
public interface IAnimal {

	public boolean lengthBelow(int size);
	public boolean isShorterThan(int size);
	
}
