
public abstract class AbsLifeForm {

	public int getNumberFour() {
		return 4;
	}
	
}
