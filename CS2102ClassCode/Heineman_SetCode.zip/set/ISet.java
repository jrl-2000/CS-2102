package set;

public interface ISet {
	ISet addElt(int elt);
	ISet removeElt(int elt);
	boolean hasElt(int elt);
	int size();
}
