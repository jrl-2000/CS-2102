package set;

public class ListSet implements ISet {
	int first;    // element of interest
	ISet rest;    // rest of the set.
	
	public ListSet(int elt, ISet rest) {
		this.first = elt;
		this.rest = rest;
	}

	/** Add element only if not exist. */
	public ISet addElt(int elt) {
		// already contained, just return self.
		if (hasElt(elt)) {
			return this;
		}
		
		return new ListSet(elt, this);
	}

	/** Remove element if it exists. */
	public ISet removeElt(int elt) {
		if (first == elt) {
			return rest;
		}
		
		return new ListSet(first, rest.removeElt(elt));
	}

	/** Check if in list. */
	public boolean hasElt(int elt) {
		if (first == elt) {
			return true;
		}
		
		return rest.hasElt(elt);
	}

	/** Return size. */
	public int size() {
		return 1 + rest.size();
	}
}

