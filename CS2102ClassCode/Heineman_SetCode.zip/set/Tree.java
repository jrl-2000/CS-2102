package set;

public class Tree implements ISet {
	int value;
	ISet left;
	ISet right;
	
	public Tree(int elt, ISet left, ISet right) {
		this.value  = elt;
		this.left   = left;
		this.right  = right;
	}

	@Override
	public ISet addElt(int elt) {
		// may already be in set.
		if (elt < value) {
			left = left.addElt(elt);
		} else if (elt > value) {
			right = right.addElt(elt);
		}
		
		return this;  
	}

	@Override
	public ISet removeElt(int elt) {
		// tricky
		return this;
	}

	@Override
	public boolean hasElt(int elt) {
		if (elt < value) {
			return left.hasElt(value);
		} else if (elt > value) {
			return right.hasElt(value);
		} else {
			return true; // is this value
		}
	}

	@Override
	public int size() {
		return 1 + left.size() + right.size();
	}

	
}
