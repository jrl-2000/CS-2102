package set;

/**
 * Represent a set as a comma-separated string of values.
 */
public class StringRepresentationSet implements ISet {

	String storage = ",";
	
	@Override
	public ISet addElt(int elt) {
		if (hasElt(elt)) { return this; }
		
		storage = "," + elt + storage;
		return this;
	}

	@Override
	public ISet removeElt(int elt) {
		if (!hasElt(elt)) { 
			return this;
		}
		
		String target = "," + elt + ",";
		int idx = storage.indexOf(target);
		storage = storage.substring(0, idx) + storage.substring(idx + target.length()-1);
		return this;
	}

	@Override
	public boolean hasElt(int elt) {
		String target = "," + elt + ",";
		int idx = storage.indexOf(target);
		return idx != -1;
	}

	@Override
	public int size() {
		int commas = 0;
		for (int i = 1; i < storage.length(); i++) {
			if (storage.charAt(i) == ',') {
				commas++;
			}
		}
		
		return commas;
	}

}
