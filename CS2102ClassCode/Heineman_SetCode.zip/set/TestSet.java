package set;

public class TestSet {
	public static ISet constructRandomSet(ISet start, int max, int numValues) {
		// add 10000 random numbers from [0 .. 100). Likely to be many duplicates!
		for (int i = 0; i < numValues; i++) {
			start = start.addElt((int)(Math.random() * max));
		}
				
		return start;
	}
	
	static void runTrial (ISet start, int maxRange, int numValues) {
		long now = System.nanoTime();
		ISet result = constructRandomSet (new EmptySet(), maxRange, numValues);
		long makeTime = System.nanoTime() - now;
		
		now = System.nanoTime();
		if (result.hasElt(-10)) {
			System.out.println("Shouldn't have negative number! This pushes to worst case.");
		}
		long checkTime = System.nanoTime() - now;

		now = System.nanoTime();
		int size = result.size();
		long sizeTime = System.nanoTime() - now;
		
		System.out.printf("%d\t%8d  %6d  %6d ( %d)\n", numValues, makeTime, checkTime, sizeTime, size);
	}
	
	public static void main(String[] args) {
		
		// burn one trial to callibrate Java Virtual machine. Watch what happens
		// if you delete this one...
		constructRandomSet (new EmptySet(), 100, 10);
		System.out.println("N\tMakeT\t  CheckT   sizeT (size)");
	
		int MAX = 8192;
		
		// validate with normal behavior.
		System.out.println("ListSet");
		for (int numValues = 64; numValues <= MAX; numValues *= 2) {
			runTrial(new EmptySet(), numValues/2, numValues);
		}
		
		System.out.println();
		
		// now try again with BadListSet.
		System.out.println("BadListSet");
		for (int numValues = 64; numValues <= MAX; numValues *= 2) {
			// this contains a single value
			ISet start = new BadListSet(numValues+1, new EmptySet());
			
			runTrial(start, numValues/2, numValues);
		}
		
		System.out.println();
		
		// now try again with String.
		System.out.println("StringRepresentationSet");
		for (int numValues = 64; numValues <= MAX; numValues *= 2) {
			// this contains a single value
			ISet start = new StringRepresentationSet();
			
			runTrial(start, numValues/2, numValues);
		}
	}
}
