package set;

public class BadListSet implements ISet {
	int first;    // element of interest
	ISet rest;    // rest of the set.
	
	public BadListSet(int elt, ISet rest) {
		this.first = elt;
		this.rest = rest;
	}

	/** Add element at all times. */
	public ISet addElt(int elt) {
		return new BadListSet(elt, this);
	}

	/** Remove element if it exists EVERYWHERE in list. */
	public ISet removeElt(int elt) {
		if (first == elt) {
			return rest.removeElt(elt);
		}
		
		return new BadListSet(first, rest.removeElt(elt));
	}

	/** Check if in list. */
	public boolean hasElt(int elt) {
		if (first == elt) {
			return true;
		}
		
		return rest.hasElt(elt);
	}

	/** How to determine size? Must count unique elements! */
	public int size() {
		ISet uniq = grabUniq(this, new EmptySet());
		return uniq.size();
	}
	
	/** Helper method that handles two cases. */
	private ISet grabUniq(ISet set, ISet unique) {
		if (set instanceof EmptySet) {
			return unique;
		}
		
		// Must be a BadList Set. Work with it instead.
		BadListSet bls = (BadListSet) set;
		if (unique.hasElt(bls.first)) {
			return grabUniq(bls.rest, unique);
		} else {
			return grabUniq(bls.rest, unique.addElt(bls.first));
		}
	}

}

