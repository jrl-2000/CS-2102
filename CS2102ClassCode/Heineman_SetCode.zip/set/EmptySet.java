package set;

public class EmptySet implements ISet {

	/** Add an element to an EmptySet by returning a ListSet. */
	public ISet addElt(int val) {
		return new ListSet(val, this);
	}

	/** Can't remove an element from Empty Set! Return self. */
	public ISet removeElt(int val) {
		return this;
	}

	/** Never contains an element. */
	public boolean hasElt(int val) {
		return false;
	}

	/** Empty set has no size. */
	public int size() {
		return 0;
	}
}
