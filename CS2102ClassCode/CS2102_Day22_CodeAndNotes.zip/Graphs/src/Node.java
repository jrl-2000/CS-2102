import java.util.LinkedList;

class Node {

    private String name;
    private LinkedList<Node> getsTo;

    public Node(String name) {
        this.name = name;
        this.getsTo = new LinkedList<Node>();
    }

    public boolean isNodeInGetsToList(Node someNode) {
    	for(Node thisNode: this.getsTo) {
    		if(thisNode.equals(someNode)) return true;
		}
    	return false;
	}

	public boolean hasRoute(Node to, LinkedList<Node> visited) {
		if (this.equals(to))
			return true;
		else if(visited.contains(this))
			return false;
		else {
			visited.add(this);
			for (Node c : this.getsTo) {
				if (c.hasRoute(to, visited)) {
					return true;
      			}
    		}
			return false;
		}
	}

	public LinkedList<Node> findRoute(Node to, LinkedList<Node> visited) {
		if (this.equals(to)) {
			LinkedList<Node> result = new LinkedList<Node>();
			result.add(to);
			return result;
		}
		else if(visited.contains(this))
			return new LinkedList<Node>();
		else {
			visited.add(this);
			for (Node c : this.getsTo) {
				LinkedList<Node> routeSoFar = c.findRoute(to, visited);

				if (routeSoFar.size() > 0) {

					routeSoFar.addFirst(this);
					return routeSoFar;
				}
			}
			return new LinkedList<Node>();
		}
	}

    public void addEdge(Node to) {
        this.getsTo.add(to);
    }
}

class SpecialNode extends Node {

	public SpecialNode() {
		super("Supernode");
		this.isNodeInGetsToList(new Node("Another node"));
	}
}
