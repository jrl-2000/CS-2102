import java.util.LinkedList;

public class RouteChecker {

    public boolean routeChecker(Node from, Node to, LinkedList<Node> path) {

        //#1: Is our starting node correct?
        boolean validPath = from.equals(path.get(0));

        //#2: Is our destination node correct?
        validPath = validPath && to.equals(path.get(path.size() - 1));

        //#3: For each pair of nodes, can we get from the first node to the second?
        for(int i = 0; i < path.size() - 1; i++) {
            Node thisNode = path.get(i + 1);
            Node prevNode = path.get(i);

            validPath = validPath && prevNode.isNodeInGetsToList(thisNode);
        }

        //#4: No node occurs more than once
        for(Node n : path) {
            int counter = 0;
            for(Node someNode : path) {
                if(n.equals(someNode)) counter++;
            }
            validPath = validPath && (counter <= 1);

        }

        return validPath;
    }
}
