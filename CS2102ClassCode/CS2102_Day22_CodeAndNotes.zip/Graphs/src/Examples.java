import org.junit.Before;
import org.junit.Test;

import java.util.LinkedList;

import static org.junit.Assert.*;

public class Examples {

    Node manc = new Node("Manchester");
    Node bost = new Node("Boston");
    Node worc = new Node("Worcester");
    Node prov = new Node("Providence");
    Node hart = new Node("Hartford");

    Graph myGraph = new Graph();

    public Examples() {
        myGraph.addNode(manc);
        myGraph.addNode(bost);
        myGraph.addNode(worc);
        myGraph.addNode(prov);
        myGraph.addNode(hart);

        myGraph.addEdge(manc, bost);
        myGraph.addEdge(bost, worc);
        myGraph.addEdge(worc, bost);
        //myGraph.addEdge(bost, prov);
        myGraph.addEdge(prov, hart);
        myGraph.addEdge(worc, hart);
    }

    @Test
    public void testFindRoute_Naive() {
        LinkedList<Node> r1 = new LinkedList<Node> ();
        r1.add(manc);
        r1.add(bost);
        r1.add(prov);
        r1.add(hart);

        LinkedList<Node> r2 = new LinkedList<Node>();
        r2.add(manc);
        r2.add(bost);
        r2.add(worc);
        r2.add(hart);

        LinkedList<Node> route = myGraph.findRoute(manc, hart);

        assertTrue(route.equals(r1) || route.equals(r2));
    }

    @Test
    public void testFindRoute() {
        LinkedList<Node> route = myGraph.findRoute(manc, hart);
        RouteChecker rc = new RouteChecker();
        assertTrue(rc.routeChecker(manc, hart, route));
    }

    @Test
    public void testFindRoute_EdgeCase() {
        LinkedList<Node> route = myGraph.findRoute(manc, manc);
        RouteChecker rc = new RouteChecker();
        assertTrue(rc.routeChecker(manc, manc, route));
    }

    @Test
    public void testHasRoute_MancHart() {
        assertTrue(myGraph.hasRoute(manc, hart));
    }

    @Test
    public void testHasRoute_MancProv() {
        assertTrue(myGraph.hasRoute(manc, prov));
    }

    @Test
    public void testHasRoute_ProvManc() {
        assertFalse(myGraph.hasRoute(prov, manc));
    }

    @Test
    public void testHasRoute_ProvProv() {
        assertTrue(myGraph.hasRoute(prov, prov));
    }

}
