import java.util.ArrayList;
import java.util.NoSuchElementException;

public class StackAL<T> {

    private ArrayList<T> stack;

    public StackAL() {
        this.stack = new ArrayList<T>();
    }

    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    public void push(T itemToAdd) {
        this.stack.add(itemToAdd);
    }

    public void pop() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.remove(this.stack.size() - 1);
        }
    }

    public void peek() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.get(this.stack.size() - 1);
        }
    }
}
