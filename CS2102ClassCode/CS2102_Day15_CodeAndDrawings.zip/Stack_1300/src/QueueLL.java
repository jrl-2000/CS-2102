import java.util.LinkedList;
import java.util.NoSuchElementException;

public class QueueLL<T> {

    private LinkedList<T> stack;

    public QueueLL() {
        this.stack = new LinkedList<T>();
    }

    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    public void add(T itemToAdd) {
        this.stack.addFirst(itemToAdd);
    }

    public void remove() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.removeLast();
        }
    }

    public void peek() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.getFirst();
        }
    }
}
