import java.util.LinkedList;
import java.util.NoSuchElementException;

public class StackLL<T> {

    private LinkedList<T> stack;

    public StackLL() {
        this.stack = new LinkedList<T>();
    }

    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    public void push(T itemToAdd) {
        this.stack.addFirst(itemToAdd);
    }

    public void pop() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.removeFirst();
        }
    }

    public void peek() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.getFirst();
        }
    }
}
