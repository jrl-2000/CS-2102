import java.util.ArrayList;
import java.util.NoSuchElementException;

public class QueueAL<T> {

    private ArrayList<T> stack;

    public QueueAL() {
        this.stack = new ArrayList<T>();
    }

    public boolean isEmpty() {
        return this.stack.isEmpty();
    }

    public void add(T itemToAdd) {
        this.stack.add(itemToAdd);
    }

    public void remove() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.remove(0);
        }
    }

    public void peek() throws NoSuchElementException {
        if(this.isEmpty()) {
            throw new NoSuchElementException("Cannot pop an empty stack!");
        }
        else {
            this.stack.get(0);
        }
    }
}
