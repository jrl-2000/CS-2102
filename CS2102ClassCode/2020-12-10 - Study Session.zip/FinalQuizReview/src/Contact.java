
public class Contact {

	String name;
	PhoneNumber phone;
	String email;
	Address thisAddress;
}

class PhoneNumber {
	String areaCode;
	String number;
}


class Address {
	String residentName;
	int num;
	String street;
	int zipcode;

	//Overriding the hashCode method in Object
	public int hashCode() {
		return 3 * num + 29 * this.residentName.hashCode() + 17 * street.hashCode() + 23 * zipcode;
	}

	//Overriding the equals method in Object
	public boolean equals(Object o) {
		Address addr = (Address) o;

		if(this.num == addr.num &&
				this.residentName == addr.residentName && 
			this.street.equals(addr.street) &&
			this.zipcode == addr.zipcode)
			return true;
		else
			return false;
	}
	
	/*
	 * Contact1:
	 * name = Will Smith
	 * Address = 123 Sunset Blvd //hashed 39298
	 * 
	 * 
	 * Contact2:
	 * name = Angelina Jolie
	 * Address = 234 Hollywood Blvd //hashed 39298
	 * 
	 * 39298 -> (Contact1, Contact2)
	 * Contact1 -> 123 = 234 && Will Smith = Angelina Jolie && ... address in Contact 1.equals(address passed in to key)
	 * Contact2 -> 234 = 234 & Angelina Jolie = Angelina Jolie && ... address in Contact 2.equals(address passed in to key)
	 * 
	 */
	
}