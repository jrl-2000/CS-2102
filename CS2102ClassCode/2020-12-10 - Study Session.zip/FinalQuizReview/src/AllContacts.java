import java.util.HashMap;
import java.util.LinkedList;

public class AllContacts {

	HashMap<Address, LinkedList<Contact>> contacts =
			new HashMap<Address, LinkedList<Contact>>();
	
	public LinkedList<Contact> getContact(Address key) {

		return this.contacts.get(key);
	}
	
	public LinkedList<Contact> addContact(Address key, Contact aContact) {
		LinkedList<Contact> contact = this.getContact(key);

		if(contact.equals(null)) {
			contact = new LinkedList<Contact>();
		}
		contact.add(aContact);
		LinkedList<Contact> oldList = contacts.put(key, contact);
		return oldList;
	}
}
