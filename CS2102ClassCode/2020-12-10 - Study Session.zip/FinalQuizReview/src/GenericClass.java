
class GenericClass<T> {
	
	private T someValue;
	
	public GenericClass(T someValue) {
		this.someValue = someValue;
	}

}

class AnotherClass {
	public void instantiateGenerics() {
		GenericClass<String> stringClass = new GenericClass("Hello world");
		GenericClass<Integer> intClass = new GenericClass(3);
	}
}