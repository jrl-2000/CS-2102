import java.util.LinkedList;
import java.util.HashMap;

class Event {
     private String type;              // wedding, etc.
     private Date date;
     private boolean isEvening;   // true if the event is to be held in the evening

     public Event(String type, Date date, boolean isEvening) {
          this.type = type;
          this.date = date;
          this.isEvening = isEvening;
     }
     
  // returns true if a conflict
     public boolean hasConflict (Event e1, Event e2){
          return date.dateSame(e1.date, e2.date) && e1.isEvening == e2.isEvening;
     }
     
     public Date getDate() {
    	 return this.date;
     }
}

class Date {
     private String month;
     private int day;
     private int year;

     public Date(String month, int day, int year) {
          this.month = month;
          this.day = day;
          this.year = year;
     }
     
     // returns true if both dates are the same
     public boolean dateSame(Date d1, Date d2) {
          return d1.month.equals(d2.month) && d1.day == d2.day && d1.year == d2.year;
     }
     
     public int hashCode() {
     	return 31*this.month.hashCode() + 29*this.day + 11*this.year;
     }
}

class ReservationSystem {
	private IReservation reservations;
	
	public ReservationSystem() {
		this.reservations = new ReservationsHashMap();
	}
	
	public boolean makeReservation(Event newEvent) {
		return reservations.bookEvent(newEvent);
	}
}

interface IReservation {
	public boolean bookEvent(Event newEvent);
}

class ReservationsLL implements IReservation {
     private LinkedList<Event> events;

     public ReservationsLL() {
          this.events = new LinkedList<Event>();
     }

     // adds the given event to the events list, as long as there is no
     // date/time conflict with existing events in the list.
     // returns true if the event was added, false otherwise
     public boolean bookEvent(Event newEvent) {
          if (events.size() == 0) {     // no other events, so no conflicts
          events.add(newEvent);
          return true;
          }
          else {
               for (Event e: this.events) {
                    if (e.hasConflict(newEvent, e))
                         return false;     // conflict found, event not added
               }
               events.add(newEvent);     // no conflicts, so add event
               return true;
          }
     }  
}

class ReservationsHashMap implements IReservation {
    private HashMap<Date, Event> events;

    public ReservationsHashMap() {
         this.events = new HashMap<Date, Event>();
    }

    // adds the given event to the events list, as long as there is no
    // date/time conflict with existing events in the list.
    // returns true if the event was added, false otherwise
    public boolean bookEvent(Event newEvent) {
         if(events.containsKey(newEvent.getDate())) {
        	 return false;
         }
         return true;
    }  
    
   
}