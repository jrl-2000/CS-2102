import java.util.LinkedList;

class BrochureList {
	LinkedList<Brochure> bList;
	
	public BrochureList(LinkedList<Brochure> bList) {
		this.bList = bList;
	}	
	
	public BrochureList() {
		this.bList = new LinkedList<Brochure>();
	}
	
	
	public void addBrochure(Brochure item) {	
		bList.add(item);
	}
	
	public int numType(String type) {
		int num = 0;
		for(Brochure s : bList) {
			if(s.type.equals(type)) {
				num = num + 1;
			}
		}
		return num;
	}
	
}

class Brochure {
	String type;
	
	public Brochure(String type) {
		this.type = type;
	}
}





	
