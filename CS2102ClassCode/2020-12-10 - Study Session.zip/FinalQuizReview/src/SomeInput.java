import java.util.Scanner;
import java.util.ArrayList;

public class SomeInput {
	Scanner keyboard = new Scanner(System.in); //don't need to know this for the quiz
	
	int[] someNumbers = new int[10]; //don't need to know this for the quiz
	
	ArrayList<Integer> someMoreNumbers = new ArrayList<Integer>();
	
	public void getSomeInput() {
		String input = keyboard.next();
		System.out.println(input);
	}
	
	public static void main(String[] args) {
		SomeInput si = new SomeInput();
		si.getSomeInput();
	}
}
