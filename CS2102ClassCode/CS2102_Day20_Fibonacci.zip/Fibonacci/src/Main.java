public class Main {

    public static void main(String[] args) {
        Fibonacci f = new Fibonacci();
        int n = 200;
        System.out.println("fibWithHash = " + f.fibHashMap(n));
        System.out.println("oldFibWay = " + f.fibOldWay(n));
    }
}
