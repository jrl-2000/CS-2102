import java.util.HashMap;

public class Fibonacci {

    private HashMap<Integer, Long> fibNums = new HashMap<Integer, Long>();

    public long fibHashMap(int n) {
        if(fibNums.containsKey(n)) {
            return fibNums.get(n);
        }
        else {
            if (n == 0) return 0L;
            if (n == 1) return 1L;

            long fibNum = this.fibHashMap(n - 1) + fibHashMap(n - 2);
            fibNums.put(n, fibNum);
            return fibNum;
        }
    }

    public long fibOldWay(int n) {
        if(n == 0) return 0L;
        if(n == 1) return 1L;

        return this.fibOldWay(n - 1) + fibOldWay(n - 2);
    }
}
