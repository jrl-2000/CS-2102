
public class RedBloodCell extends BloodCell {

	//Methods
	transportGases()
}
