
public class abstract BloodCell extends Cell{

	//have and do what is common to all
	//blood cells
	
}
