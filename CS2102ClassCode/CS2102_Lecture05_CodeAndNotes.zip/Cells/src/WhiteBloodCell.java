
public class WhiteBloodCell extends BloodCell {

	
	//Methods
	defendTheBodyFromInvaders();
}
