
public class BasophilCell extends WhiteBloodCell {

	//do whatever is specific to Basophil
}
