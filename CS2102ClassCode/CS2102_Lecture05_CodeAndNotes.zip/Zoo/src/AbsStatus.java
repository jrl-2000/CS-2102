
public abstract class AbsStatus {

}
