
public interface IStatus {

	public boolean isItWorthStealing();
}
