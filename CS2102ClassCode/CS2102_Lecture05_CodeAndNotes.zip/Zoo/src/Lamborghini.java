
public class Lamborghini implements IStatus {

}
