
public interface IList {

	public int countBooks();
}
