public interface IBorrowable {
	double lateFee(int days);
}

class Library {
	LinkedList<LibItem> holdings = new LinkedList<LibItem>();

	Library(LinkedList<LibItem> holdings) {
		this.holdings = holdings;
	}

	LibItem findByTitle(String title) {
		for(LibItem anItem : this.holdings) {
			if(anItem.title.equals(title)){
				return anItem;
			}
		}
		return null;
	}
}

class abstract LibItem {

	String title;
	String location;
	
	LibItem(String title, String location) {
		this.title = title;
		this.location = location;
	}
	
}

class Reference extends LibItem {


	Reference(String title, String location) {
		super(title, location);
	}
}


class abstract CirculatingItem extends LibItem implements IBorrowable {
	int timesOut;
	boolean isAvailable;
	
	CirculatingItem(String title, String location, int timesOut, boolean isAvailable) {
		super(title, location);
		this.timesOut = timesOut;
		this.isAvailable = isAvailable;
	}
	
	CirculatingItem checkIn() {
		this.isAvailable = true;
		return this;
	}

	CirculatingItem checkOut() {
		this.isAvailable = false;
		this.timesOut++;
		return this;
	}
}

class Book extends CirculatingItem {

	Book(String title, String location, int timesOut, boolean isAvailable) {
		super(title, location, timesOut, isAvailable);
	}
	
	double lateFee(int days) {
		return 0.25 * days;
	}

}


class DVD extends CirculatingItem  {


	DVD(String title, String location, int timesOut, boolean isAvailable) {
		super(title, location, timesOut, isAvailable);
	}

	double lateFee(int days) {
		if(days <= 3) {
			return 5.0;
		}
		else
			return 20.0;
	}

}

class Member {
	String name;
	LinkedList<CirculatingItem> checkedOut;
	double lateFees;
	
	Member(String name, LinkedList<CirculatingItem> checkedOut, double lateFees) {
		this.name = name;
		this.checkedOut = checkedOut;
		this.lateFees = lateFees;
	}
}