import java.util.LinkedList;

public class Node {

    private String name;
    private LinkedList<Node> getsTo;

    public Node(String name) {
        this.name = name;
        this.getsTo = new LinkedList<Node>();
    }

    public boolean hasRoute(Node to) {
        return true;
    }

    public void addEdge(Node to) {
        this.getsTo.add(to);
    }
}
