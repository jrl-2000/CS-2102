import java.util.LinkedList;

public class Graph {

    private LinkedList<Node> nodes;

    public Graph() {
        this.nodes = new LinkedList<Node>();
    }

    public void addEdge(Node from, Node to) {
        from.addEdge(to);
    }

    public void addNode(Node someNode) {
        this.nodes.add(someNode);
    }

    public boolean hasRoute(Node from, Node to) {
        return from.hasRoute(to);
    }

}
