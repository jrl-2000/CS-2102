public class Examples {

    Node manc = new Node("Manchester");
    Node bost = new Node("Boston");
    Node worc = new Node("Worcester");
    Node prov = new Node("Providence");
    Node hart = new Node("Hartford");

    Graph myGraph = new Graph();

    public Examples() {
        myGraph.addNode(manc);
        myGraph.addNode(bost);
        myGraph.addNode(worc);
        myGraph.addNode(prov);
        myGraph.addNode(hart);

        myGraph.addEdge(manc, bost);
        myGraph.addEdge(bost, worc);
        myGraph.addEdge(worc, bost);
        myGraph.addEdge(bost, prov);
        myGraph.addEdge(prov, hart);

        myGraph.hasRoute(manc, prov);
    }
}
