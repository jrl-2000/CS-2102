import java.util.LinkedList;

class Customer {
    private String name;
    private int password;
    private LinkedList<Account> accounts;

    public Customer(String name, int password) {
    	this.name = name;
    	this.password = password;
    }
    
    public boolean checkName(String name) {
        return this.name.equals(name);
    }

    public boolean checkPassword(int pwd) {
        return this.password == pwd;
    }
}

class Account {
    private int number;
    private Customer owner;
    private double balance;

    public boolean checkNumber(int acctNum) {
        return this.number == acctNum;
    }

    //Getter
    public double getBalance() {
        return this.balance;
    }

    public void withdraw(double amt) {
        this.balance = this.balance - amt;
    }
}

class CheckingAccount extends Account {

    //Overriding
    public boolean checkNumber(int acctNum) {
        return super.checkNumber(acctNum);
    }
}

class BankingService {
    private IAcctDataStructure accounts;
    private ICustDataStructure customers;

    public BankingService(IAcctDataStructure accounts, ICustDataStructure customers) {
    	this.accounts = accounts;
    	this.customers = customers;
    }
    
    void addCust(Customer cust) {
    	customers.addCust(cust);
    }
    
    double getBalance(int forAcctNum) {

       Account acct;
       try {
           acct = accounts.findByNumber(forAcctNum);
       }
       catch(NullPointerException e) {
           return 0;
       }
       return acct.getBalance();

    }

    double withdraw(int forAcctNum, double amt) {
        Account acct;
        try {
            acct = accounts.findByNumber(forAcctNum);
        }
        catch(NullPointerException e) {
            return 0;
        }
        acct.withdraw(amt);
        return amt;
    }

    String login(String custname, int withPwd)
            throws CustomerNotFoundException, LoginFailedException {
        Customer cust = customers.findCustomer(custname, withPwd);
        return "Welcome!";
    }

}