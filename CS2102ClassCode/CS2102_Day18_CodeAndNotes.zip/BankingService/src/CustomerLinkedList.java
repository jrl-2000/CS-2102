import java.util.LinkedList;

public class CustomerLinkedList implements ICustDataStructure {

    private LinkedList<Customer> customers;

    public CustomerLinkedList() {
        this.customers = new LinkedList<Customer>();
    }

    public void addCust(Customer cust) {
        this.customers.add(cust);
    }

    public Customer findCustomer(String custname, int withPwd)
            throws LoginFailedException, CustomerNotFoundException {
        Customer cust = this.findCustomerName(custname);
        this.checkPassword(cust, withPwd);
        return cust;
    }

    public Customer findCustomerName(String custname) throws CustomerNotFoundException {
        for (Customer cust:customers) {
            if (cust.checkName(custname)) {
                return cust;
            }
        }
        throw new CustomerNotFoundException(custname);
    }

    public void checkPassword(Customer cust, int withPwd) throws LoginFailedException {
        if(!cust.checkPassword(withPwd)) throw new LoginFailedException();
    }
}
