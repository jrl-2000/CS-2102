public class LoginFailedException extends Exception {


    public LoginFailedException() {
    }


}
