public class CustomerNotFoundException extends Exception {

    private String unfoundName;

    public CustomerNotFoundException(String msg) {
        this.unfoundName = msg;
    }

    public String getUnfoundName() {
        return this.unfoundName;
    }
}
