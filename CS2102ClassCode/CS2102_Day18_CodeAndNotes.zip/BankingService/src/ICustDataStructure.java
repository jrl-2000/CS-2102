public interface ICustDataStructure {

    public Customer findCustomer(String custname, int withPwd)
            throws LoginFailedException, CustomerNotFoundException;
    public void addCust(Customer cust);
}
