
public class DataBST implements IBST<PhoneBookEntry> {

	PhoneBookEntry data;
	IBST<PhoneBookEntry> left;
	IBST<PhoneBookEntry> right;
	
	public boolean hasElt(PhoneBookEntry elt) {
		if(this.data.compareTo(elt) == 0)
			return true;
		else if (this.data.compareTo(elt) < 0)
			return this.left.hasElt(elt);
		else
			return this.right.hasElt(elt);
	}
	
}
