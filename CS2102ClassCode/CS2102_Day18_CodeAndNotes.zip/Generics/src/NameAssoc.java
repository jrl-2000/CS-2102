public class NameAssoc<T> {
	String name;
	T data;
	
	NameAssoc(String name, T data) {
		this.name = name;
		this.data = data;
	}

	public void updateValForName (String forname, T newData) {
			if (this.name.equals(forname)) {
					this.data = newData;
			}
	}
}