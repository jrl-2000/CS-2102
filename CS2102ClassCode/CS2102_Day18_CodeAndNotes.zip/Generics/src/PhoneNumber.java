
public class PhoneNumber {
	int areaCode;
	int number;
}
