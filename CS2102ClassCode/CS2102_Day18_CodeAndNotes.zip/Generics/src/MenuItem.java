class MenuItem extends NameAssoc<Integer> {

	public MenuItem(String name, int price) {
		super(name, price);
	}
}