
public interface IBST <T extends Comparable<T>> {
	boolean hasElt(T elt);
}
