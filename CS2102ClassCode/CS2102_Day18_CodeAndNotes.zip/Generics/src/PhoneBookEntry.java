class PhoneBookEntry extends NameAssoc<PhoneNumber> implements Comparable<PhoneBookEntry> {

	public PhoneBookEntry(String name, PhoneNumber phnum) {
		super(name, phnum);
	}
	
	public int compareTo(PhoneBookEntry other) {
		if(this.data.areaCode < other.data.areaCode) {
			return -1;
		}
		else if(this.data.areaCode > other.data.areaCode) {
			return 1;
		}
		else return 0;
	}
	
}