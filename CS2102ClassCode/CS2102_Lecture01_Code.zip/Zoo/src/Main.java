
public class Main {

	public static void main(String[] args) {
		Dillo babyDillo = new Dillo(8, false);
		Dillo adultDillo = new Dillo(24, false);
		Dillo hugeDeadDillo = new Dillo(65, true);

		boolean returnVal = babyDillo.canShelter(adultDillo);
		System.out.println(returnVal);
		
	}

}
