import java.util.HashMap;
import java.util.LinkedList;

class NotFreshRecordHashMap {
	
	//HashMap of lists of items that need to be removed
	//Key - Department name
	//Value - List of items to remove in that department
	private HashMap<String, LinkedList<GroceryItem>> expiredItems;

	public NotFreshRecordHashMap() {
		this.expiredItems = new HashMap<String, LinkedList<GroceryItem>>();
	}
	
	public NotFreshRecordHashMap(HashMap<String, LinkedList<GroceryItem>> expiredItems) {
		this.expiredItems = expiredItems;
	}
	
	public void addGroceryItem(String name, GroceryItem item)
	{
		try {
			LinkedList<GroceryItem> checkForList = this.getGroceryItem(name);
			checkForList.add(item);
			expiredItems.put(name, checkForList);
		}
		catch (ItemNotFoundException e) {
			LinkedList<GroceryItem> gItem = new LinkedList<GroceryItem>();
			gItem.add(item);
			expiredItems.put(name, gItem);
		}
	}
	
	public LinkedList<GroceryItem> getGroceryItem(String name) throws ItemNotFoundException {
		if(expiredItems.containsKey(name)) {
			return expiredItems.get(name);
		}
		else throw new ItemNotFoundException();
	}
}

class ItemNotFoundException extends Exception {
	
}

class GroceryItem {
	private String name;
	private String dept;
	private int numDaysOnShelf;
	private int expDate;
	
	public GroceryItem(String name, String dept, int numDaysOnShelf, int expDate) {
		this.name = name;
		this.dept = dept;
		this.numDaysOnShelf = numDaysOnShelf;
		this.expDate = expDate;
	}
}