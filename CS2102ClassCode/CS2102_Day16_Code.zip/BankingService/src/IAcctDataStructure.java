public interface IAcctDataStructure {

    public Account findByNumber(int forAcctNum);
}
