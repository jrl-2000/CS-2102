import java.util.LinkedList;

public class MaxTripleLength {
	
	int maxTripleLength(LinkedList<String> strs) {
		
		int maxLength = 0;
		
		for(int i = 0; i < strs.size(); i++) {
			//loop 1, i = 0: String triple = strs.get(0) + strs.get(1) + strs.get(2); suntwogood
			//loop 2, i = 1; String triple = strs.get(1) + strs.get(2) + strs.get(3); twogoodbad
			//loop 3, i = 2; 
			//loop 4, i = 3;
			//loop 5, i = 4; String triple = strs.get(4) + strs.get(5) + strs.get(6); <-- ARRAYOUTOFBOUNDS
			String triple = strs.get(i) + strs.get(i + 1) + strs.get(i + 2);
			
			if(maxLength < triple.length()) {
				maxLength = triple.length();
			}
			
		}
		
		return maxLength;
	
	}
	}
