public class Triple {
    String triple;
    int tripleLength;

    public Triple(String triple) {
        this.triple = triple;
        this.tripleLength = triple.length();
    }
}
