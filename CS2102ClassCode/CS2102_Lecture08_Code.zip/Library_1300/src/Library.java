import java.util.LinkedList;

/**
 * A collection of books.
 */
public class Library {

    LinkedList<Book> books = new LinkedList<Book>();


    public Library(LinkedList<Book> books) {
        this.books = books;
    }

    //Overloading
    public Library() {
        this.books = new LinkedList<Book>();
    }

    public Library addBook(Book aBook) {
        this.books.add(aBook);
        return this;
    }

    public int countBooks() {
        //return books.size();

        //Accumulator
        int numBooks = 0;
        for(Book aBook : books) {
            numBooks = numBooks + 1;
            //numBooks++;
        }

        return numBooks;
    }

    /**
     * Searches for a book with a matching title.
     * @param myTitle The title we're searching for.
     * @return True if a matching book is found.
     */
    public boolean hasTitle(String myTitle) {
        for(Book aBook : books) {
            if(aBook.title.equals(myTitle)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets all of the books that are checked out
     * in the library.
     * @return A list of checked out books.
     */
    public LinkedList<Book> checkedOut() {
        LinkedList<Book> checkedOutBooks = new LinkedList<Book>();
        for(Book aBook : books) {
            if(!aBook.isAvailable) {
                checkedOutBooks.add(aBook);
            }
            //numBooks++;
        }

        return checkedOutBooks;
    }

}
