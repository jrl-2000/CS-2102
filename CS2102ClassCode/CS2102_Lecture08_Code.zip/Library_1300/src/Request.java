public class Request {

    Book aBook;
    int cardNum;

    public Request(Book aBook, int cardNum) {
        this.aBook = aBook;
        this.cardNum = cardNum;
    }

    //Overloaded
    public Request(Book aBook) {
        this.aBook = aBook;
    }

}
