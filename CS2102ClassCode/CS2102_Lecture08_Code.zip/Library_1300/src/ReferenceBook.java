public class ReferenceBook extends Book {

    public ReferenceBook(String title, String callNum) {
        super(title, callNum);
    }

    //Overriding
    public Book checkOut() {
        //other stuff here
        //super.checkOut();
        return null;
    }

    //Overriding
    public boolean timeToReplace() {
        return false;
    }

    public Request makeRequest(int cardNum) {
        //Check a book out in library for two hours

        return null;
    }
}
