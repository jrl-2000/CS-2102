public class EmptyList implements IList {

    //Default constructor
    //public EmptyList() {

    //}

    public int countBooks() {
        return 0;
    }

}
