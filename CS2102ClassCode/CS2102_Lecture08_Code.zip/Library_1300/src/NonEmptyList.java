public class NonEmptyList implements IList {

    String aString;
    IList restOfList;

    public NonEmptyList(String aString, IList restOfList) {
        this.aString = aString;
        this.restOfList = restOfList;
    }

    public int countBooks() {
        return 1 + restOfList.countBooks();
    }

}
