import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class Examples {

    Book hamlet = new Book("hamlet", "SH123", 0, true);
    Book hamletAgain = hamlet;
    Book hamletAThirdTime = new Book("hamlet", "SH123", 0, true);


    Book macBeth = new Book("macbeth", "SH234");
    Book muchado = new Book(0, "muchado", "SH345", true);

    Request reqHamlet = hamlet.makeRequest(1234);
    Request getHamletAgain = new Request(hamlet, 1234);

    Library myLib;

    public Examples() {

    }

    @Before
    public void setup() {
        hamlet.isAvailable = true;
        macBeth.isAvailable = true;
        myLib = new Library();
        myLib.addBook(hamlet).addBook(macBeth).addBook(muchado);
    }

    //Edge case
    @Test
    public void testCheckedOutEmptyList() {
        assertEquals(myLib.checkedOut(), new LinkedList<Book>());
    }

    @Test
    public void testCheckedOutNonEmptyList() {
        hamlet.isAvailable = false;
        macBeth.isAvailable = false;
        LinkedList<Book> expectedOutput = new LinkedList<Book>();
        expectedOutput.add(macBeth);
        expectedOutput.add(hamlet);
        assertEquals(myLib.checkedOut(), expectedOutput);
    }

    @Test
    public void testCheckOut() {
        assertEquals(hamlet.checkOut(), hamletAThirdTime);
    }

}
