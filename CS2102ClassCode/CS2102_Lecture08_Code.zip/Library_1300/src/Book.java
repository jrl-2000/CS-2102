public class Book {

    String title;
    String callNum;
    int timesOut;
    boolean isAvailable;

    public Book(String title, String callNum, int timesOut, boolean isAvailable) {
        this.title = title;
        this.callNum = callNum;
        this.timesOut = timesOut;
        this.isAvailable = isAvailable;
    }

    //Overloading
    public Book(String title, String callNum) {
        this.title = title;
        this.callNum = callNum;
        this.timesOut = 0;
        this.isAvailable = true;
    }

    //Overloading
    public Book(int timesOut, String title, String callNum, boolean isAvailable) {
        this.title = title;
        this.callNum = callNum;
        this.timesOut = timesOut;
        this.isAvailable = isAvailable;
    }

    public Request makeRequest(int cardNum) {
        return new Request(this, cardNum);
    }

    public Book checkOut() {
        //mutator
        this.timesOut = this.timesOut + 1;
        //this.timesOut += 1;
        this.isAvailable = false;
        return this;
    }

    public void checkIn() {
        this.isAvailable = true;
    }

    public boolean timeToReplace() {
        //Chaining
        return this.checkOut().timesOut > 400;
    }

    //Overriding equals() method from Object
    public boolean equals(Object o) {
        Book otherBook = (Book) o;

        if(otherBook.title.equals(this.title) &&
            otherBook.callNum.equals(this.callNum)) {
            return true;
        }

        return false;

    }

}
