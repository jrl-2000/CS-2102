
public class Fruit {

	String nameOfFruit;
	
	public Fruit(String nameOfFruit) {
		this.nameOfFruit = nameOfFruit;
	}
}
