import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		LinkedList<Fruit> applesPears = new LinkedList<Fruit>();
		applesPears.add(new Fruit("pears"));
		applesPears.add(new Fruit("apples"));
		
		Fruit pears = applesPears.get(1);
	}

}
