
public class ReferenceBook extends Book {

	public ReferenceBook(String title, String callNum) {
		super(title, callNum);
	}
	
	//overriding
	public Book checkOut() {
		return null;
	}
	
	
	
}
