
public class Request {

	Book aBook;
	int cardNum;
	
	public Request(Book aBook, int cardNum) {
		this.aBook = aBook;
		this.cardNum = cardNum;
	}
}
