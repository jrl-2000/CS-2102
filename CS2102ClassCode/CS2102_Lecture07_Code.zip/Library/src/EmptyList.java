
public class EmptyList implements IList {

	//default constructor
	public EmptyList() {
		
	}
	
	public int countBooks() {
		return 0;
	}
	
}
