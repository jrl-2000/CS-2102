
public class Dillo implements IAnimal {

	int length;
	boolean isDead;
	
	public Dillo(int lengthParam, boolean isDeadParam) {
		this.length = lengthParam;
		this.isDead = isDeadParam;
	}
	
	public boolean canShelter(Dillo aDillo) {
		if(aDillo.length > 60 && aDillo.isDead == true) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean lengthBelow(int size) {
		return this.length < size;
	}
}
