
public interface IAnimal {

	public boolean lengthBelow(int size);
	
}
